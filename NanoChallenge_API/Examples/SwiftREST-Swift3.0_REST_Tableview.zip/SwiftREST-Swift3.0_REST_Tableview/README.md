# SwiftREST
Demo Code for REST API backed tableview: http://grokswift.com/rest-tableview-in-swift/

Creates a tableview that displays Star Wars species from SWAPI.io
