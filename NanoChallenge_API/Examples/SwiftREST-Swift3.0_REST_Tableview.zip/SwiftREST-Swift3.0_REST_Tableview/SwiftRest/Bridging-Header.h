//
//  Bridging-Header.h
//  SwiftRest
//
//  Created by Christina Moulton on 2015-02-21.
//  Copyright (c) 2015 Teak Mobile Inc. All rights reserved.
//

#ifndef SwiftRest_Bridging_Header_h
#define SwiftRest_Bridging_Header_h

//#import "Alamofire/Alamofire.h"

#endif
