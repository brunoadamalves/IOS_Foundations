//
//  BooksListWorker.swift
//  GoogleBooks
//
//  Created by Carmelo Gallo on 9/18/17.
//  Copyright (c) 2017 Carmelo Gallo. All rights reserved.
//

import UIKit

class BooksListWorker {
    
    func doSomeWork() {
        
    }
}
