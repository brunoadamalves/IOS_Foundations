//
//  BookDetailsModels.swift
//  GoogleBooks
//
//  Created by Carmelo Gallo on 9/19/17.
//  Copyright (c) 2017 Carmelo Gallo. All rights reserved.
//

import UIKit

enum BookDetails {
    // MARK: - Use cases
    enum Something {
        struct Request {
            
        }
        struct Response {
            
        }
        struct ViewModel {
            
        }
    }
}
