//
//  ViewController.swift
//  Class13
//
//  Created by Nicolas Nascimento on 22/05/19.
//  Copyright © 2019 Nicolas Nascimento. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager = CLLocationManager()
    
    
    let workLocation = CLLocation(latitude: -30.0593446, longitude: -51.1734912)
    let homeLocation = CLLocation(latitude: -30.1606415, longitude: -51.1793402)
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        mapView.delegate = self
        let homeAnnotation = MapLocation(title: "Home", coordinate: homeLocation.coordinate)
        let workAnnotation = MapLocation(title: "Work", coordinate: workLocation.coordinate)
        
        mapView.addAnnotation(homeAnnotation)
        mapView.addAnnotation(workAnnotation)
        
        
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(didTap(recognizer:)))
        mapView.addGestureRecognizer(recognizer)
        
        setupLocationManager()
    }
    
    
    @objc func didTap(recognizer: UITapGestureRecognizer) {
        
        
        let homePlacemark = MKPlacemark(coordinate: homeLocation.coordinate)
        let workPlacemark = MKPlacemark(coordinate: workLocation.coordinate)
        
        let homeMapItem = MKMapItem(placemark: homePlacemark)
        let workMapItem = MKMapItem(placemark: workPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = homeMapItem
        directionRequest.destination = workMapItem
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            guard let response = response else { fatalError() }
            
            let route = response.routes.first!
            self.mapView.addOverlay(route.polyline, level: .aboveRoads)
            let rect = route.polyline.boundingMapRect
            let largerRect = MKMapRect(origin: rect.origin,
                                       size: MKMapSize(width: rect.size.width*1.1, height: rect.size.height*1.1))
            self.mapView.setVisibleMapRect(largerRect, animated: true)
        }
        
    }
    
    
    fileprivate func setupLocationManager() {
        locationManager.delegate = self
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            startUpdating(locationManager)
        } else {
            locationManager.requestWhenInUseAuthorization()
        }
    }

    // MARK: - Location Manager
    
    fileprivate func startUpdating(_ manager: CLLocationManager) {
        
        manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        manager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        if status == .authorizedWhenInUse {
            
            startUpdating(manager)
            
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        print(locations)
        
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {

        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = .red
        renderer.lineWidth = 4
        return renderer

    }
    

}

