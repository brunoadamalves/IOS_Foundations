//
//  MapLocation.swift
//  FavoritePlaces
//
//  Created by Nicolas Nascimento on 10/10/18.
//  Copyright © 2018 Nicolas Nascimento. All rights reserved.
//

import MapKit

class MapLocation: NSObject, MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D
    
    var title: String?
    
    init(title: String, coordinate: CLLocationCoordinate2D) {
        self.coordinate = coordinate
        self.title = title
        super.init()
    }
    
    var subtitle: String? { return "I'm at \(coordinate)" }
}
