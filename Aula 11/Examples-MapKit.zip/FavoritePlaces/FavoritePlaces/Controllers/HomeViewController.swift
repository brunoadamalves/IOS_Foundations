//
//  ViewController.swift
//  FavoritePlaces
//
//  Created by Nicolas Nascimento on 09/10/18.
//  Copyright © 2018 Nicolas Nascimento. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

final class HomeViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet private weak var mapView: MKMapView!
    
    let workLocation = CLLocation(latitude: -30.0593446,
                                  longitude: -51.1734912)
    let homeLocation = CLLocation(latitude: -30.1606415,
                                  longitude: -51.1793402)
    
    let locationManager = CLLocationManager()
    
    // MARK: - View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupLocationManager()
        setupMapView()
        setupLongPressGesture()
    }
    
    @IBAction func didTapRouteButton(_ sender: UIButton) {

        
        let homePlacemark = MKPlacemark(coordinate: homeLocation.coordinate)
        let workPlacemark = MKPlacemark(coordinate: workLocation.coordinate)
        
        let homeMapItem = MKMapItem(placemark: homePlacemark)
        let workMapItem = MKMapItem(placemark: workPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = homeMapItem
        directionRequest.destination = workMapItem
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            guard let response = response else { fatalError() }
            
            let route = response.routes.first!
            self.mapView.addOverlay(route.polyline, level: .aboveRoads)
            let rect = route.polyline.boundingMapRect
            let largerRect = MKMapRect(origin: rect.origin,
                                       size: MKMapSize(width: rect.size.width*1.1, height: rect.size.height*1.1))
            self.mapView.setVisibleMapRect(largerRect, animated: true)
        }
    }
    
    private func updateLocation() {
        locationManager.startUpdatingLocation()
        locationManager.desiredAccuracy = kCLLocationAccuracyKilometer
    }
    
    private func setupLocationManager() {
        locationManager.delegate = self
        
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            updateLocation()
        } else {
            locationManager.requestWhenInUseAuthorization()
        }
    }
}

extension HomeViewController {
    
    private func setupMapView() {
        mapView.delegate = self
        mapView.showsUserLocation = true
        
        // Center Map
        centerMap(on: homeLocation.coordinate)
        
        // Locations
        let homeAnnotationView = MapLocation(title: "Home",
                                       coordinate: homeLocation.coordinate)
        
        let workAnnotationView = MapLocation(title: "Work",
                                       coordinate: workLocation.coordinate)
        
        // Create Annotation
        mapView.addAnnotation(homeAnnotationView)
        mapView.addAnnotation(workAnnotationView)
    }
    
    private func setupLongPressGesture() {
        // Long press to recognize
        let gestureRecognizer = UILongPressGestureRecognizer(target: self,
                                                             action:#selector(handleTap(recognizer:)))
        mapView.addGestureRecognizer(gestureRecognizer)
    }
    
    @objc func handleTap(recognizer: UILongPressGestureRecognizer) {
        
        let location = recognizer.location(in: mapView)
        let coordinate = mapView.convert(location, toCoordinateFrom: mapView)
        
        // Add pin
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        mapView.addAnnotation(annotation)
    }
}


extension HomeViewController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
            updateLocation()
        default:
            break
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        print(location)
    }
}


// MARK: - Map View Delegate
extension HomeViewController: MKMapViewDelegate {
    
    private func centerMap(on coordinate: CLLocationCoordinate2D) {
        let region = MKCoordinateRegion(center: coordinate,
                                        span: MKCoordinateSpan(latitudeDelta: 1,
                                                               longitudeDelta: 1))
        mapView.setRegion(region, animated: false)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let annotation = annotation as? MapLocation else { return nil }
        
        let id = "marker"
        let view: MKMarkerAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: id) as? MKMarkerAnnotationView {
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else {
            view = MKMarkerAnnotationView(annotation: annotation,
                                          reuseIdentifier: id)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: -5)
            view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        return view
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = .red
        renderer.lineWidth = 4
        return renderer
        
    }
    
    
}
