//
//  TaskItem.swift
//  Challange
//
//  Created by Bruno Adam Alves on 21/05/19.
//  Copyright © 2019 Bruno Adam Alves. All rights reserved.
//

import Foundation
import CoreData

@objc(TaskItem)
public class TaskItem: NSManagedObject {
    
}
